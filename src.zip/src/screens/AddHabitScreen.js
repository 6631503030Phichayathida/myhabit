import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import AsyncStorage from '@react-native-async-storage/async-storage';

const AddHabitScreen = ({ navigation }) => {
  const [personalityName, setPersonalityName] = useState('');
  const [frequency, setFrequency] = useState('daily');
  const [time, setTime] = useState('');

  const frequencies = [
    { label: 'Every Day', value: 'daily' },
    { label: 'Even Days', value: 'even' },
    { label: 'Odd Days', value: 'odd' },
    { label: 'Weekdays', value: 'weekdays' },
    { label: 'Weekends', value: 'weekends' },
  ];

  const handleSubmit = async () => {
    if (!personalityName.trim()) {
      Alert.alert('Error', 'Please enter a personality name');
      return;
    }

    if (!time.trim()) {
      Alert.alert('Error', 'Please enter a time');
      return;
    }

    try {
      const newHabit = {
        id: Date.now().toString(),
        personalityName: personalityName.trim(),
        frequency,
        time: time.trim(),
        completed: false,
        createdAt: new Date().toISOString(),
      };

      // Get existing habits
      const existingHabits = await AsyncStorage.getItem('habits');
      const habits = existingHabits ? JSON.parse(existingHabits) : [];

      // Add new habit
      const updatedHabits = [...habits, newHabit];

      // Save to AsyncStorage
      await AsyncStorage.setItem('habits', JSON.stringify(updatedHabits));

      Alert.alert('Success', 'Habit added successfully!', [
        { text: 'OK', onPress: () => navigation.goBack() }
      ]);
    } catch (error) {
      Alert.alert('Error', 'Failed to save habit');
      console.error('Error saving habit:', error);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.formContainer}>
        <Text style={styles.title}>Add New Habit</Text>
        
        <View style={styles.inputContainer}>
          <Text style={styles.label}>Personality Name</Text>
          <TextInput
            style={styles.input}
            value={personalityName}
            onChangeText={setPersonalityName}
            placeholder="Enter personality name"
            placeholderTextColor="#999"
          />
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>Frequency</Text>
          <View style={styles.pickerContainer}>
            <Picker
              selectedValue={frequency}
              onValueChange={(itemValue) => setFrequency(itemValue)}
              style={styles.picker}
            >
              {frequencies.map((item) => (
                <Picker.Item 
                  key={item.value} 
                  label={item.label} 
                  value={item.value} 
                />
              ))}
            </Picker>
          </View>
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>Time</Text>
          <TextInput
            style={styles.input}
            value={time}
            onChangeText={setTime}
            placeholder="Enter time (e.g., 06:00)"
            placeholderTextColor="#999"
            keyboardType="numbers-and-punctuation"
          />
        </View>

        <TouchableOpacity 
          style={styles.submitButton}
          onPress={handleSubmit}
        >
          <Text style={styles.submitButtonText}>Save Habit</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  formContainer: {
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
  },
  inputContainer: {
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
    color: '#333',
  },
  input: {
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#ddd',
    fontSize: 16,
  },
  pickerContainer: {
    backgroundColor: 'white',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#ddd',
    overflow: 'hidden',
  },
  picker: {
    height: 50,
  },
  submitButton: {
    backgroundColor: '#6b46c1',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 20,
  },
  submitButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
});

export default AddHabitScreen; 