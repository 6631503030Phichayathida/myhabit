import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const theme = {
  primary: '#6B46C1', // Main purple
  secondary: '#9F7AEA', // Lighter purple
  background: '#F7FAFC', // Light background
  text: '#2D3748', // Dark text
  white: '#FFFFFF',
};

const HomeScreen = ({ navigation }) => {
  const [habits, setHabits] = useState([]);

  useEffect(() => {
    loadHabits();
  }, []);

  const loadHabits = async () => {
    try {
      const storedHabits = await AsyncStorage.getItem('habits');
      if (storedHabits) {
        setHabits(JSON.parse(storedHabits));
      }
    } catch (error) {
      console.error('Error loading habits:', error);
      Alert.alert('Error', 'Failed to load habits');
    }
  };

  const toggleHabit = async (id) => {
    try {
      const updatedHabits = habits.map(habit => 
        habit.id === id ? { ...habit, completed: !habit.completed } : habit
      );
      
      await AsyncStorage.setItem('habits', JSON.stringify(updatedHabits));
      setHabits(updatedHabits);
    } catch (error) {
      console.error('Error updating habit:', error);
      Alert.alert('Error', 'Failed to update habit');
    }
  };

  const deleteHabit = async (id) => {
    try {
      const updatedHabits = habits.filter(habit => habit.id !== id);
      await AsyncStorage.setItem('habits', JSON.stringify(updatedHabits));
      setHabits(updatedHabits);
    } catch (error) {
      console.error('Error deleting habit:', error);
      Alert.alert('Error', 'Failed to delete habit');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>My Habits</Text>
      <ScrollView style={styles.habitList}>
        {habits.length === 0 ? (
          <Text style={styles.emptyText}>No habits yet. Add your first habit!</Text>
        ) : (
          habits.map(habit => (
            <View key={habit.id} style={styles.habitItem}>
              <View style={styles.habitInfo}>
                <Text style={styles.habitName}>{habit.personalityName}</Text>
                <Text style={styles.habitTime}>{habit.time}</Text>
                <Text style={styles.habitFrequency}>{habit.frequency}</Text>
              </View>
              <View style={styles.habitActions}>
                <TouchableOpacity
                  style={[styles.checkButton, habit.completed && styles.checked]}
                  onPress={() => toggleHabit(habit.id)}
                >
                  <Text style={styles.checkText}>{habit.completed ? '✔' : ''}</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.deleteButton}
                  onPress={() => deleteHabit(habit.id)}
                >
                  <Text style={styles.deleteText}>×</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))
        )}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: theme.background,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: theme.text,
  },
  habitList: {
    flex: 1,
  },
  emptyText: {
    textAlign: 'center',
    color: theme.text,
    fontSize: 16,
    marginTop: 20,
  },
  habitItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: theme.white,
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  habitInfo: {
    flex: 1,
  },
  habitName: {
    fontSize: 16,
    fontWeight: '600',
    color: theme.text,
  },
  habitTime: {
    fontSize: 14,
    color: theme.secondary,
    marginTop: 4,
  },
  habitFrequency: {
    fontSize: 12,
    color: theme.secondary,
    marginTop: 2,
  },
  habitActions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  checkButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 2,
    borderColor: theme.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  checked: {
    backgroundColor: theme.primary,
  },
  checkText: {
    color: theme.white,
    fontSize: 18,
  },
  deleteButton: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: '#FF3B30',
    justifyContent: 'center',
    alignItems: 'center',
  },
  deleteText: {
    color: theme.white,
    fontSize: 20,
    fontWeight: 'bold',
  },
});

export default HomeScreen; 